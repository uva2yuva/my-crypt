// resemble knee robust zone shed swallow garbage mechanic rubber apple unfold blue


import "../stylesheets/app.css";
import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'
// Import our contract artifacts and turn them into usable abstractions.
import metacoin_artifacts from '../../build/contracts/MetaCoin.json'

//import "/home/nn2ht03/hte/bignumber.min.js";

// MetaCoin is our usable abstraction, which we'll use through the code below.
var MetaCoin = contract(metacoin_artifacts);

// The following code is simple to show off interacting with your contracts.
// As your needs grow you will likely need to change its form and structure.
// For application bootstrapping, check out window.addEventListener below.

var accounts;
var account, account2;
var balance;


window.App = {

  start: function() {

    var self = this;

    // Bootstrap the MetaCoin abstraction for Use.
    MetaCoin.setProvider(web3.currentProvider);

    // Get the initial account balance so it can be displayed.
    web3.eth.getAccounts(function(err, accs) {
    console.log("accounts are " +accs.length);
    alert("err " +err);
      if (err != null) {

      alert("There was an error fetching your accounts.");
        return;
      }

      if (accs.length == 0) {

        alert("Couldn't get any accounts! Make sure your Ethereum client is configured correctly.");
        return;
      }

      accounts = accs;
      console.log("accounts are1 " +accounts);
      account = accounts[0];
      account2 = web3.eth.accounts[1];
      console.log('available Accounts : ' +accs);
      console.log('Owner account[' + accounts[0] + '] = ' + web3.eth.getBalance(accounts[0])  );



      self.refreshBalance();
    });
  },

  setStatus: function(message) {
    var status = document.getElementById("status");
    status.innerHTML = message;
  },

  refreshBalance: function() {
    var self = this;
    var amount = parseInt(document.getElementById("amount").value);
    console.log('Trans Amt : '+ amount)
    balance = web3.eth.getBalance(account);
    console.log('curr balance of owner : '+ balance);
    var meta;
    MetaCoin.deployed(balance).then(function(instance) {
     meta = instance;
      return   meta.getBalance.call(account, balance, {from: account});
    }).then(function(value) {
        console.log('value: ' + value);
        value = web3.fromWei(web3.eth.getBalance(account),'ether');
        console.log('Eth Value ' + value);
        var balance_element = document.getElementById("balance");
      balance_element.innerHTML = value.valueOf();
    //  var ob = web3.eth.getBalance(account);
    var receiver1 = document.getElementById("receiver").value;
      var rece = web3.fromWei(web3.eth.getBalance(receiver1),'ether');
    var ownbalance_element = document.getElementById("ownbalance");
    ownbalance_element.innerHTML = rece;
    var receiv = web3.eth.getBalance(account2);
     console.log('receiver account[' + account2 + '] = ' + receiv  );

        console.log('Receiver balance ETH :' + rece);
      }).catch(function(e) { console.log(e);
      self.setStatus("Error getting balance; see log.");
    });
  },
  sendCoin: function() {
    var self = this;
    var amount = parseInt(document.getElementById("amount").value);
    var receiver = document.getElementById("receiver").value;
    console.log("receivee " + receiver);
    this.setStatus("Initiating transaction... (please wait)");
     var meta;
      MetaCoin.deployed(balance).then(function(instance) {
       meta = instance;
       meta.sendTransaction({from:account, to: account2, value: amount}).then(function(result){
        console.log("senddd " + JSON.stringify(result));
        //console.log("watch " + JSON.stringify(result));
        //console.log("watch " + JSON.stringify(result.args._value));
      //});
    });
      return meta.sendCoin(receiver, amount, {from: account});
    }).then(function() {

    //      meta.send(web3.toWei(amount, "ether")).then(function(result){
   //meta.Transfer().watch((error, result) => {


      self.setStatus("Transaction complete!");
      self.refreshBalance();

    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error sending coin; see log.");
    });
  }
};

window.addEventListener('load', function() {

  // Checking if Web3 has been injected by the browser (Mist/MetaMask)
  if (typeof web3 !== 'undefined') {
    console.warn("Using web3 detected from external source. If you find that your accounts don't appear or you have 0 MetaCoin, ensure you've configured that source properly. If using MetaMask, see the following link. Feel free to delete this warning. :) http://truffleframework.com/tutorials/truffle-and-metamask")
    // Use Mist/MetaMask's provider
    window.web3 = new Web3(web3.currentProvider);
  } else {
    //console.warn("No web3 detected. Falling back to http://127.0.0.1:9545. You should remove this fallback when you deploy live, as it's inherently insecure. Consider switching to Metamask for development. More info here: http://truffleframework.com/tutorials/truffle-and-metamask");
     //fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
    window.web3 = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:8545"));
  }

  App.start();
});



//  var aa = JSON.stringify(a);
  //console.log('aa : ' +aa);
  //console.log('a : ' +util.inspect(aa,false,null));
//  console.log('a : '+ a['logs'][0]['args']['_from']);



/*checkBalance: function() {
    var self = this;
    var acctAddress = document.getElementById("address").value;
      var check_element = document.getElementById("chk_Balance");

      this.setStatus("Retreving Balance... (please wait)");

      MetaCoin.deployed().then(function(instance){
        return instance.checkBalance(acctAddress);
      }).then(function(balance) {
              console.log(balance.toString(10));
              console.log(balance.toNumber());
          })
          .catch(function(error) {
              console.error(error);
          });
https://stackoverflow.com/questions/45614208/how-to-send-ether-from-eoa-to-contract?rq=1
}*/

/*.then(function(value){
    var balance_element = document.getElementById("chk_balance");

    var rece = web3.fromWei(web3.eth.getBalance(receiver),'ether');
    rece = rece.toNumber(); console.log(rece);

    balance_element.innerHTML = rece.valueOf();
    console.log('value : ' + value);

      })*/



  /*
  Available Accounts
  ==================
  (0) 0x9bd40d641518faeeb7dcff515be51753c71a9dff
  (1) 0xa5653d8d4830b9ab062dea5d2fff7ad59cedfb0f
  (2) 0x0681a5959bc2d666e52954e5c1e48c93d96e8450
  (3) 0x2400efe0186076bdd60c4c7dd4d1d138c18fa46b
  (4) 0x3ecbf9cfcd8249ea30ecbaaeda31dff1f714e2a5
  (5) 0x312eb6db9971e91a8c11dffe1e8d06e585b6ab82
  (6) 0x969f227e70b96d69aebb91b797d398228841e090
  (7) 0x77366ea96ea1d800acdfdbb92000afc86cdc81a9
  (8) 0x3246b45922426f147ac3454235e27b1afdd83d8f
  (9) 0x378df4843485e4241ba8d340c4b814dcad9265c6

  Private Keys
  ==================
  (0) 413afaf69b57008671c298e80cd950630c5e51a2755f62229d885a2ed881e157
  (1) 544d923867b4a641c8664a2c2d5cde764c17f47c2ed0b2cc354a1c2136e9fb55
  (2) c0da3767b5bfb514477079297a95817ab72f0739ff21bb3fc8d9773ca52dcaa2
  (3) 081bcc233ebbf191d6e3eb6d9a94c1cc162edc3ab3e588ebfad9c04364304d31
  (4) 1a1533306a18f12f3011f293392c34e8280f7a3d50e45ff1bd989ef67c7fcfb0
  (5) e7f7abefa86b197411041210704d51c52bc93e0796ae1a30a9f2927614ce75d2
  (6) 7e46fb2b9006b9d84816adf764baf0e2abf2f8c572fe7964e71a14a767757d9f
  (7) 8f21f44a17b5c52f081107c3898af851817c0a6eba9d147145b718d4eb062310
  (8) 1bf3760fd9ad1737029492cb7cfb7ddd31b9ed9970c8a5c18f8dc1ccad2f537b
  (9) b6b0b93ce76329d6948723a2a9fa44954f92dfeade3a92b01a549da519b24858

  HD Wallet
  ==================
  Mnemonic:      resemble knee robust zone shed swallow garbage mechanic rubber apple unfold blue

  */


   /*{"tx":"0x05874ceab3cdeb47083c4eef263288dda16e07ae8469fe55339cbb6cc6cb76d4",
   "receipt":
    {
     "transactionHash":"0x05874ceab3cdeb47083c4eef263288dda16e07ae8469fe55339cbb6cc6cb76d4",
   "transactionIndex":0,
   "blockHash":"0x533f4875df6ad35e2c27882b22374c653cfb4b18465befb1b4abf4e98722f3b5",
   "blockNumber":18,
   "gasUsed":35924,
   "cumulativeGasUsed":35924,
   "contractAddress":null,
   "logs":[{"logIndex":0,"transactionIndex":0,
   "transactionHash":"0x05874ceab3cdeb47083c4eef263288dda16e07ae8469fe55339cbb6cc6cb76d4",
   "blockHash":"0x533f4875df6ad35e2c27882b22374c653cfb4b18465befb1b4abf4e98722f3b5",
   "blockNumber":18,"address":"0xe1a17a20d839dd6dde6862dc47c43e6133814259",
   "data":"0x0000000000000000000000000000000000000000000000000000000000000001",
   "topics":["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
   "0x000000000000000000000000b2c7f776932b06450bc40920a55515b5c6b63c3a",
   "0x0000000000000000000000005a114d0c874c62ec9a671c9c370f2f9ac26c113e"],
   "type":"mined"}],
   "status":1
    },
   "logs":[{"logIndex":0,"transactionIndex":0,
   "transactionHash":"0x05874ceab3cdeb47083c4eef263288dda16e07ae8469fe55339cbb6cc6cb76d4",
   "blockHash":"0x533f4875df6ad35e2c27882b22374c653cfb4b18465befb1b4abf4e98722f3b5",
   "blockNumber":18,"address":"0xe1a17a20d839dd6dde6862dc47c43e6133814259","type":"mined","event":"Transfer",
   "args":{"_from":"0xb2c7f776932b06450bc40920a55515b5c6b63c3a","_to":"0x5a114d0c874c62ec9a671c9c370f2f9ac26c113e",
   "_value":"1"}}]}*/
