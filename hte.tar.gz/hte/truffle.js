// Allows us to use ES6 in our migrations and tests.
require('babel-register')

module.exports = {
  networks: {
    development: {
      host: 'localhost',
      port: 8545,
      network_id: '*' ,// Match any network id
      from: '0xb2c7f776932b06450bc40920a55515b5c6b63c3a'
     // gas:4720098,
     // gasPrice: 10000000000
   }

   //  uv: {
   //   host: '178.0.0.12',
   //   port: 8545,
   //   network_id: 1 ,// Match any network id
   //  from: '0xb2c7f776932b06450bc40920a55515b5c6b63c3a',
   //  gas:4700098,
   //  gasPrice: 10000000000
   //
   // }
  }
}
